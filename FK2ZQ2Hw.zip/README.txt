========================================================================
                              9 6 . b o x
========================================================================

 Welcome to the isolated virtual node of the 96.box environment!

------------------------------------------------------------------------
 [ SYSTEM INFORMATION ]
------------------------------------------------------------------------
 Architecture:    Spaghetti
 Environment:     WebOS, Mikesoft Windows 96
 URL:             https://windows96.net/?rootfs=https://

------------------------------------------------------------------------
 [ IMPORTANT NOTE ]
------------------------------------------------------------------------

    All changes made to this virtual file system
    are TEMPORARY. Reloading the page or closing the browser tab will
    wipe the data and reset the environment to its default ROOTFS state.
